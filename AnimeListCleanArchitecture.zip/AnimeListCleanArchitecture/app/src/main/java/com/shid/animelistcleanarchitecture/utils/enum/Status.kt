package com.shid.animelistcleanarchitecture.utils.enum

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}