package com.shid.animelistcleanarchitecture.framework.database.entities

interface AnimeType {
}