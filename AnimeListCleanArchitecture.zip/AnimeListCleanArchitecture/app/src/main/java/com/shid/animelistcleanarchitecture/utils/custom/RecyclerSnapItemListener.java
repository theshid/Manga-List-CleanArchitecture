package com.shid.animelistcleanarchitecture.utils.custom;

public interface RecyclerSnapItemListener {
    void onItemSnap(int position);
}
