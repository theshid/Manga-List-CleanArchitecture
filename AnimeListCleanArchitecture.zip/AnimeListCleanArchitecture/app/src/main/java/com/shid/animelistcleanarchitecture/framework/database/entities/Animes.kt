package com.shid.animelistcleanarchitecture.framework.database.entities

data class Animes(val animes: List<AnimeType>)
