package com.shid.animelistcleanarchitecture.utils.enum

enum class More(val type:String) {
    AIRING("airing"),
    UPCOMING("upcoming"),
    TV("tv"),
    MOVIE("movie"),
    OVA("ova")
}