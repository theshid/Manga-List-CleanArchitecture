package com.shid.animelistcleanarchitecture.utils.enum

enum class Season(val value: String) {
    SPRING("Spring"),
    SUMMER("Summer"),
    FALL("Fall"),
    WINTER("Winter")
}